$(document).ready(function(e) {
	//adds a + icon to the left of the button
	$('#add-todo').button({icons:{primary:"ui-icon-circle-plus"}});
	
	//adding the dialogue box
	//modal = true -> allows user to close dialog box
	//autoOpen = false -> does not auto open when webpage is opened
	$('#new-todo').dialog({modal:true,autoOpen:false});
	
	//makes dialog box open when button is clicked
	$('#add-todo').button({
		icons:{primary:"ui-icon-circle-plus"}}).click(		
			function(){$('#new-todo').dialog('open');}						
			);
	
	//adding two buttons to the dialog box
	$('#new-todo').dialog({
		modal:true,autoOpen:false,
		buttons:{
			"Add task":function(){
				//adding task to list, and checks if it is an empty string
				var taskName = $('#task').val();
					if (taskName === '') { return false; }
					var taskHTML = '<li><span class="done">%</span>';
					taskHTML += '<span class="delete">x</span>';
					taskHTML += '<span class="task"></span></li>';
					
					//???
					var $newTask = $(taskHTML);
					$newTask.find('.task').text(taskName);
					
			//close dialog box once a new task is added
			$newTask.hide();
			$('#todo-list').prepend($newTask);
			$newTask.show('clip',250).effect('highlight',1000);
			$(this).dialog('close');	
			
			//resets the value in the input box to be ''
			$('#task').val('');
			},		
			
			"Cancel":function(){
				$(this).dialog('close');
				$('#task').val('');			
			}		
		}	
		
	});
	
	//marking complete
	$('#todo-list').on('click','.done',function(){
			var $taskItem = $(this).parent('li');
			$taskItem.slideUp(250,function (){
				var $this = $(this); //$(this) is the HTML element. $(this) is what is in the memory
				//remove HTML element from the page (but is still in memory)
				$this.detach();			
				
				//moving the dettached element to another list in HTML
				$('#completed-list').prepend($this);
				$this.slideDown();
			}); 
		})	;	
	
	//supporting drag and drop
	//making both lists sortable
	$('.sortlist').sortable({
			//connect two lists together in order to drag and drop accross two different lists (they both have the same class)
			connectWith:'.sortlist',
			cursor:'pointer', //changes cursor to a pointer when it is dragged 
			placeholder:'ui-state-highlight',	//highlights space in list where user can drop item
			cancel:'.delete,.done'	//does not allow user to drag from the check box and the delete icon
	});
		
	//adding the dialogue box
	//modal = true -> allows user to close dialog box
	//autoOpen = false -> does not auto open when webpage is opened
	$('#deleteTask').dialog({modal:true,autoOpen:false});
	
	//delete function
	var taskDel = {};	//global variable used in order to store an object that needs to be deleted in another function
	$('.sortlist').on('click','.delete',function(){
		taskDel = $(this);
		$('#deleteTask').dialog('open');
		//
	});
	
	
	//adding two buttons to the dialog box
	$('#deleteTask').dialog({
		modal:true,autoOpen:false,
		buttons:{
			"Yes":function(){
				taskDel.parent('li').effect('puff',function(){taskDel.remove();});	//puff is the animation effect
				$(this).dialog('close');	
			},		
			
			"No":function(){$(this).dialog('close');}		
		}	
		
	});
	

	
	}); // end ready